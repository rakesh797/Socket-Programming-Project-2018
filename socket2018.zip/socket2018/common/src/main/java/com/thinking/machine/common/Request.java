package com.thinking.machine.common;
import java.io.*;
public class Request implements Serializable
{
private Object object;
private String entity;
private Operation.OPERATION_TYPE operation;
public void setObject(Object object)
{
this.object=object;
}
public Object getObject()
{
return this.object;
}
public void setEntity(String entity)
{
this.entity=entity;
}
public String getEntity()
{
return this.entity;
}
public void setOperationType(Operation.OPERATION_TYPE operation)
{
this.operation=operation;
}
public Operation.OPERATION_TYPE getOperationType()
{
return this.operation;
}
}