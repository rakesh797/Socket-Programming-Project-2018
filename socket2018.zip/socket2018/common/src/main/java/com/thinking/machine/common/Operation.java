package com.thinking.machine.common;
import java.io.*;
public interface Operation
{
public enum OPERATION_TYPE{ADD,UPDATE,DELETE};
public static final OPERATION_TYPE ADD=OPERATION_TYPE.ADD;
public static final OPERATION_TYPE UPDATE=OPERATION_TYPE.UPDATE;
public static final OPERATION_TYPE DELETE=OPERATION_TYPE.DELETE;
}