package com.thinking.machine.manager;
import java.io.*;
public class Student implements Serializable 
{
private int rollNumber;
private String name;
private char gender;
private String address;
public void setRollNumber(int rollNumber)
{
this.rollNumber=rollNumber;
}
public int getRollNumber()
{
return this.rollNumber;
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setGender(char gender)
{
this.gender=gender;
}
public char getGender()
{
return this.gender;
}
public void setAddress(String address)
{
this.address=address;
}
}