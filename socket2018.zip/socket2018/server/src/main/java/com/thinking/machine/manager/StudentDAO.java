package com.thinking.machine.manager;
public class StudentDAO
{
public void add(Student student)
{
System.out.println("SAVE HOGAYA");
}
}