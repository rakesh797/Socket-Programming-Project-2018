package com.thinking.machine.server;
import java.io.*;
import java.net.*;
import com.thinking.machine.manager.*;
import com.thinking.machine.common.*;
public class RequestProcessor extends Thread
{
private Socket socket;
public RequestProcessor(Socket socket)
{
this.socket=socket;
start();
}
public void run()
{
try
{
byte header[]=new byte[10];
InputStream inputStream;
OutputStream outputStream;
inputStream=socket.getInputStream();
ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
byte bytes[]=new byte[1024];
int byteCount;
System.out.println("Fetching data..........");
inputStream.read(header);
int contentLength=0;
int e,f;
for(e=0;e<=9;e++)
{
System.out.print(header[e]+" ");
}
e=9;
f=1;
while(e>=0)
{
contentLength=contentLength+(header[e]*f);
e--;
f=f*10;
}
System.out.println("Content length :"+contentLength);
int bytesRead=0;
while(true)
{
byteCount=inputStream.read(bytes);
if(byteCount<0) break;
bytesRead+=byteCount;
byteArrayOutputStream.write(bytes,0,byteCount);
if(bytesRead==contentLength) break;
}
System.out.println("Data fetched, now parsing it");
bytes=byteArrayOutputStream.toByteArray();
ByteArrayInputStream byteArrayInputStream=new ByteArrayInputStream(bytes);
ObjectInputStream objectInputStream=new ObjectInputStream(byteArrayInputStream);
Request request=(Request)objectInputStream.readObject();
Manager manager=new Manager(request.getOperationType(),request.getEntity(),request.getObject());
outputStream=socket.getOutputStream();
String response="OK";
byte b[]=response.getBytes();
outputStream.write(b,0,b.length);
outputStream.flush();
System.out.println("Reponse sent");
socket.close();
}catch(Exception exception)
{
System.out.println(exception);
}
}
}