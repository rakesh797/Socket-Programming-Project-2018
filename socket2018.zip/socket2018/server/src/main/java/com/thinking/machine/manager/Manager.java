package com.thinking.machine.manager;
import com.thinking.machine.common.*;
public class Manager implements Operation
{
private Object object;
private String entity;
private Operation.OPERATION_TYPE operation;
public Manager(Operation.OPERATION_TYPE operation,String entity,Object object)
{
this.object=object;
this.entity=entity;
this.operation=operation;
this.process();
}
public void process()
{
if(entity.equals("Student"))
{
if(Operation.OPERATION_TYPE.ADD==operation)
{
System.out.println("Add Chalega");
//StudentDAO studentDAO=new StudentDAO((Student)object);
}
}
}
}