package com.thinking.machine.server;
import com.thinking.machine.common.*;
import java.io.*;
import java.net.*;
public class Server
{
private ServerSocket serverSocket;
private int portNumber;
public Server(int portNumber)
{
this.portNumber=portNumber;
try
{
serverSocket=new ServerSocket(portNumber);
startListening();
}catch(Exception exception)
{
System.out.println(exception);
}
}
public void startListening()
{
try
{
Socket socket;
while(true)
{
System.out.println("Server is listening on port : "+this.portNumber);
socket=serverSocket.accept();
System.out.println("Request arrived ");
new RequestProcessor(socket);
}
}catch(Exception exception)
{
System.out.println(exception);
}
}
}
