import com.thinking.machine.server.*;
class startServer
{
public static void main(String data[])
{
int portNumber=Integer.parseInt(data[0]);
Server server=new Server(portNumber);
}

}