package com.thinking.machine.student.dl;
import com.thinking.machine.client.*;
import com.thinking.machine.common.*;
public class StudentDAO implements Operation
{
public Request request;
public void addStudent(Student student)
{
request=new Request();
request.setObject(student);
request.setEntity("Student");
request.setOperationType(Operation.OPERATION_TYPE.ADD);
Client client=new Client(request);
client.client("localhost",8090);
}
public void updateStudent(Student student)
{
request=new Request();
request.setObject(student);
request.setEntity("Student");
request.setOperationType(Operation.OPERATION_TYPE.UPDATE);
Client client=new Client(request);
}
public void deleteStudent(int rollNumber)
{
request=new Request();
request.setObject(new Integer(rollNumber));
request.setEntity("Student");
request.setOperationType(Operation.OPERATION_TYPE.ADD);
Client client=new Client(request);
}
}
