package com.thinking.machine.client;
import com.thinking.machine.employeeInfo.employee.dl.*;
public EmployeeClient
{

}