package com.thinking.machine.server;
import com.thinking.machine.employeeInfo.employee.dl.*;
public EmployeeServer implements java.io.Serializibility<Employee>
{

}