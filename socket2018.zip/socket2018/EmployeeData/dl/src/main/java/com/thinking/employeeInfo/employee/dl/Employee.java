package com.thinking.machine.employeeInfo.employee.dl;
public class Employee
{
private int employeeId;
private String name;
private String fathersName;
private char gender;
private String dateOfBirth;
private int age;
private int accountNumber;
private int contactNumber;
private String address;
private String email;
private String department;
private String post;
private int salary;
private String bloodGroup;
private String status;
private String religion;
private String nationality;
public void setEmployeeId(int employeeId)
{
this.employeeId=employeeId;
}
public int getEmployeeId()
{
return this.employeeId;
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setfathersName(String fathersName)
{
this.fathersName=fathersName;
}
public String getfathersName()
{
return this.fathersName;
}
public void setGender(char gender)
{
this.gender=gender;
}
public char getGender()
{
return this.gender;
}
public void setDateOfBirth(String dateOfBirth)
{
this.dateOfBirth=dateOfBirth;
}
public String getDateOfBirth()
{
return this.dateOfBirth;
}
public void setAge(int age)
{
this.age=age;
}
public int getAge()
{
return this.age;
}
public void setAccountNumber(int accountNumber)
{
this.accountNumber=accountNumber;
}
public int getAccountNumber()
{
return this.accountNumber;
}
public void setContactNumber(int contactNumber)
{
this.contactNumber=contactNumber;
}
public int getContactNumber()
{
return this.contactNumber;
}
public void setAddress(String address)
{
this.address=address;
}
public String getAddress()
{
return this.address;
}
public void setEmail(String email)
{
this.email=email;
}
public String getEmail()
{
return this.email;
}
public void setDepartment(String department)
{
this.department=department;
}
public String getDepartment()
{
return this.department;
}
public void setPost(String post)
{
this.post=post;
}
public String getPost()
{
return this.post;
}
public void setSalary(int salary)
{
this.salary=salary;
}
public int getSalary()
{
return this.salary;
}
public void setBloodGroup(String bloodGroup)
{
this.bloodGroup=bloodGroup;
}
public String getBloodGroup()
{
return this.bloodGroup;
}
public void setStatus(String status)
{
this.status=status;
}
public String getStatus()
{
return this.status;
}
public void setReligion(String religion)
{
this.religion=religion;
}
public String getReligion()
{
return this.religion;
}
public void setNationality(String nationality)
{
this.nationality=nationality;
}
public String getNationality()
{
return this.nationality;
}
}