import com.thinking.machine.student.dl.*;
import com.thinking.machine.client.*;
class StudentAddTestCase
{
public static void main(String gg[])
{
Student student=new Student();
student.setRollNumber(101);
student.setName("Rahul");
student.setGender('M');
student.setAddress("Bhopal");
StudentDAO studentDAO=new StudentDAO();
studentDAO.add(student);
}
}