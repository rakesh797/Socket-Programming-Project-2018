package com.thinking.machine.client;
import com.thinking.machine.common.*;
import java.io.*;
import java.net.*;
public class Client
{
private Request request=new Request();
public Client(Request request)
{
this.request=request;
}
public void client(String server,int portNumber)
{
try
{
ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
ObjectOutputStream objectOutputStream=new ObjectOutputStream(byteArrayOutputStream);
objectOutputStream.writeObject(request);
objectOutputStream.flush();
byte bytes[]=byteArrayOutputStream.toByteArray();
int size=bytes.length;
byte header[]=new byte[10];
int s=size;
for(int i=9;i>=0;i--)
{
header[i]=(byte)(s%10);
s=s/10;
}
Socket socket=new Socket(server,portNumber);
OutputStream outputStream=socket.getOutputStream();
int bufferSize=1024;
int numberOfBytesToWrite;
int i=0;
System.out.println("Sending data............");
outputStream.write(header,0,10);
while(i<bytes.length)
{
numberOfBytesToWrite=bufferSize;
if(i+bufferSize>bytes.length)
{
numberOfBytesToWrite=bytes.length-i;
}
outputStream.write(bytes,i,numberOfBytesToWrite);
outputStream.flush();
i=i+bufferSize;
}
System.out.println("Data Sent.............");
InputStream inputStream=socket.getInputStream();
byteArrayOutputStream=new ByteArrayOutputStream();
byte b[]=new byte[1024];
int bytesCount; 
while(true)
{
bytesCount=inputStream.read(b);
if(bytesCount<0) break;
byteArrayOutputStream.write(b,0,bytesCount);
}
b=byteArrayOutputStream.toByteArray();
String reponse=new String(b);
socket.close();
}
catch(Exception exception)
{
System.out.println(exception);
}
}
}